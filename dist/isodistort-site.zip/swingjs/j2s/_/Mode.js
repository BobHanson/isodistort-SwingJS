(function(){var P$=Clazz.newPackage("_"),p$1={},I$=[[0,'org.byu.isodistort.local.MathUtil','java.awt.Color']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Mode");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['isActive'],'I',['type','count','columnCount','numTypes'],'O',['modesPerType','int[]','typePanels','javax.swing.JPanel[]','fileModeCoeffsTMSA','double[][][][][]','initAmpTM','double[][]','+maxAmpTM','irrepTM','int[][]','nameTM','String[][]','sliderTM','javax.swing.JSlider[][]','sliderLabelsTM','javax.swing.JLabel[][]','sliderValsTM','double[][]','+savedSliderValues','+vector','colorT','java.awt.Color[]','delta','double[]','numSubTypes','int[]','numSubAtoms','int[][]']]]

Clazz.newMeth(C$, 'c$$I$I$IA$IAA',  function (type, numTypes, numSubTypes, numSubAtoms) {
;C$.$init$.apply(this);
this.numTypes=numTypes;
this.numSubTypes=numSubTypes;
this.numSubAtoms=numSubAtoms;
this.type=type;
switch (type) {
case 0:
case 2:
case 3:
this.columnCount=3;
break;
case 1:
case 6:
this.columnCount=1;
break;
case 4:
case 5:
this.columnCount=6;
break;
}
this.delta=Clazz.array(Double.TYPE, [this.columnCount]);
}, 1);

Clazz.newMeth(C$, 'initAtoms$',  function () {
});

Clazz.newMeth(C$, 'initArraysNonAtom$I',  function (num) {
this.isActive=true;
this.count=num;
this.nameTM=Clazz.array(String, [1, num]);
this.modesPerType=Clazz.array(Integer.TYPE, -1, [num]);
this.initAmpTM=Clazz.array(Double.TYPE, [1, num]);
this.maxAmpTM=Clazz.array(Double.TYPE, [1, num]);
switch (this.type) {
case 5:
this.columnCount=6;
this.irrepTM=Clazz.array(Integer.TYPE, [1, num]);
this.vector=Clazz.array(Double.TYPE, [num, 6]);
break;
case 6:
for (var m=0; m < this.count; m++) {
this.initAmpTM[0][m]=this.maxAmpTM[0][m]=1;
}
break;
}
});

Clazz.newMeth(C$, 'initArraysMode$IA$I',  function (perType, count) {
this.isActive=true;
this.count=count;
this.modesPerType=perType;
this.initAmpTM=Clazz.array(Double.TYPE, [this.numTypes, null]);
this.maxAmpTM=Clazz.array(Double.TYPE, [this.numTypes, null]);
this.irrepTM=Clazz.array(Integer.TYPE, [this.numTypes, null]);
this.nameTM=Clazz.array(String, [this.numTypes, null]);
this.fileModeCoeffsTMSA=Clazz.array(Double.TYPE, [this.numTypes, null, null, null, null]);
for (var t=0; t < this.numTypes; t++) {
var nmodes=this.modesPerType[t];
this.irrepTM[t]=Clazz.array(Integer.TYPE, [nmodes]);
this.initAmpTM[t]=Clazz.array(Double.TYPE, [nmodes]);
this.maxAmpTM[t]=Clazz.array(Double.TYPE, [nmodes]);
this.nameTM[t]=Clazz.array(String, [nmodes]);
this.fileModeCoeffsTMSA[t]=Clazz.array(Double.TYPE, [nmodes, null, null, null]);
var nsub=this.numSubTypes[t];
var natom=this.numSubAtoms[t];
for (var m=0; m < nmodes; m++) {
this.fileModeCoeffsTMSA[t][m]=Clazz.array(Double.TYPE, [nsub, null, null]);
for (var s=0; s < nsub; s++) this.fileModeCoeffsTMSA[t][m][s]=Clazz.array(Double.TYPE, [natom[s], this.columnCount]);

}
}
});

Clazz.newMeth(C$, 'getModeData$org_byu_isodistort_local_Variables_VariableParser',  function (parser) {
var modeTracker=Clazz.array(Integer.TYPE, [this.numTypes]);
var subAtoms=parser.numSubAtomsRead;
for (var pt=0, m=0; m < this.count; m++) {
var thisType=parser.getInt$I(pt++) - 1;
var mode=modeTracker[thisType]++;
if (mode + 1 != parser.getInt$I(pt++)) p$1.parseError$S$I.apply(parser, ["The modes are not given in ascending order", 2]);
this.initAmpTM[thisType][mode]=parser.getDouble$I(pt++);
this.maxAmpTM[thisType][mode]=parser.getDouble$I(pt++);
this.irrepTM[thisType][mode]=parser.getInt$I(pt++) - 1;
this.nameTM[thisType][mode]=parser.getItem$I(pt++);
for (var s=0; s < this.numSubTypes[thisType]; s++) {
for (var a=0; a < subAtoms[thisType][s]; a++) {
for (var i=0; i < this.columnCount; i++) {
this.fileModeCoeffsTMSA[thisType][mode][s][a][i]=parser.getDouble$I(pt++);
}
}
}
}
});

Clazz.newMeth(C$, 'calcDistortion$org_byu_isodistort_local_Variables$DAAA$DA$DAA',  function (v, max, tempvec, tempmat) {
var irrepVals=v.modes[6].sliderValsTM[0];
var superVal=v.superSliderVal;
for (var ia=0, n=v.numAtoms; ia < n; ia++) {
var a;
$I$(1).vecfill$DA$D(this.delta, 0);
var t=a.t;
var s=a.s;
if (this.isActive) {
if (a.modes[this.type] == null ) {
a.modes[this.type]=Clazz.array(Double.TYPE, [this.modesPerType[t], null]);
for (var m=0; m < this.modesPerType[t]; m++) {
a.modes[this.type][m]=this.fileModeCoeffsTMSA[t][m][s][a.a];
}
}for (var m=0; m < this.modesPerType[t]; m++) {
var d=irrepVals[this.irrepTM[t][m]] * this.sliderValsTM[t][m] * superVal ;
$I$(1).vecadd$DA$DA$D$DA(this.delta, a.modes[this.type][m], d, this.delta);
}
}var v1=a.vector1[this.type];
if (v1 == null ) {
v1=a.vector1[this.type]=Clazz.array(Double.TYPE, [this.columnCount]);
}$I$(1).vecadd$DA$DA$D$DA(a.vector0[this.type], this.delta, 1, v1);
switch (this.columnCount) {
case 1:
max[t][s][this.type]+=v1[0] / this.numSubAtoms[t][s];
break;
case 3:
$I$(1).mul$DAA$DA$DA(v.sBasisCart, v1, tempvec);
var d=$I$(1).len3$DA(tempvec);
if (d > max[t][s][this.type] ) max[t][s][this.type]=d;
break;
case 6:
$I$(1).voigt2matrix$DA$DAA(v1, tempmat);
$I$(1).mul$DAA$DAA$DAA(v.sBasisCart, tempmat, tempmat);
$I$(1).mul$DAA$DAA$DAA(tempmat, v.sBasisCartInverse, tempmat);
d=0;
for (var i=0; i < 3; i++) {
for (var j=0; j < 3; j++) {
d+=tempmat[i][j] * tempmat[i][j];
}
}
if (d > max[t][s][4] ) max[t][s][4]=d;
}
}
});

Clazz.newMeth(C$, 'saveMode$',  function () {
if (!this.isActive) return;
if (this.savedSliderValues == null ) {
this.savedSliderValues=Clazz.array(Double.TYPE, [this.numTypes, null]);
for (var t=0; t < this.numTypes; t++) {
this.savedSliderValues[t]=Clazz.array(Double.TYPE, [this.modesPerType[t]]);
}
}for (var t=0; t < this.numTypes; t++) {
for (var m=0; m < this.modesPerType[t]; m++) {
this.savedSliderValues[t][m]=this.sliderValsTM[t][m];
}
}
});

Clazz.newMeth(C$, 'randomizeModes$java_util_Random$Z',  function (rval, isGM) {
if (!this.isActive) return;
for (var t=0; t < this.numTypes; t++) {
for (var m=0; m < this.modesPerType[t]; m++) {
var name=this.nameTM[t][m];
var isGM1=(name.startsWith$S("GM1") && !name.startsWith$S("GM1-") );
if (isGM1 == isGM ) {
this.sliderValsTM[t][m]=(2 * rval.nextFloat$() - 1) * this.maxAmpTM[t][m];
} else if (isGM) {
this.sliderValsTM[t][m]=0;
}}
}
});

Clazz.newMeth(C$, 'restoreMode$',  function () {
if (!this.isActive) return;
for (var t=0; t < this.numTypes; t++) {
for (var m=0; m < this.modesPerType[t]; m++) {
this.sliderValsTM[t][m]=this.savedSliderValues[t][m];
}
}
});

Clazz.newMeth(C$, 'colorPanels$',  function () {
if (this.typePanels == null  || !this.isActive ) return;
for (var t=0; t < this.numTypes; t++) {
var c=this.colorT[t];
this.typePanels[t].setBackground$java_awt_Color(c);
for (var m=0; m < this.modesPerType[t]; m++) {
this.sliderLabelsTM[t][m].setBackground$java_awt_Color(c);
this.sliderTM[t][m].setBackground$java_awt_Color(c);
}
}
});

Clazz.newMeth(C$, 'setSliders$I',  function (n) {
if (!this.isActive) return;
switch (this.type) {
case 5:
case 6:
for (var m=0; m < this.count; m++) this.sliderTM[0][m].setValue$I(n);

break;
default:
for (var t=0; t < this.numTypes; t++) {
for (var m=0; m < this.modesPerType[t]; m++) this.sliderTM[t][m].setValue$I(n);

}
break;
}
});

Clazz.newMeth(C$, 'resetSliders$I',  function (sliderMax) {
if (!this.isActive) return;
switch (this.type) {
case 5:
this.numTypes=this.count;
break;
case 6:
for (var m=0; m < this.count; m++) this.sliderTM[0][m].setValue$I(sliderMax);

break;
default:
for (var t=0; t < this.numTypes; t++) {
for (var m=0; m < this.modesPerType[t]; m++) this.sliderTM[t][m].setValue$I(((this.initAmpTM[t][m] / this.maxAmpTM[t][m] * sliderMax)|0));

}
break;
}
});

Clazz.newMeth(C$, 'readSlider$D$D$org_byu_isodistort_local_Mode',  function (superSliderVal, sliderMaxVal, irreps) {
var isAtomic=(this.type < 5);
var isIrrep=(this.type == 6);
var prec=(isAtomic ? 2 : 3);
var n=(isAtomic ? this.numTypes : 1);
for (var t=0; t < n; t++) {
for (var m=0; m < this.modesPerType[t]; m++) {
this.sliderValsTM[t][m]=this.maxAmpTM[t][m] * (this.sliderTM[t][m].getValue$() / sliderMaxVal);
var d=this.sliderValsTM[t][m] * (isIrrep ? 1 : irreps.sliderValsTM[0][this.irrepTM[t][m]]) * superSliderVal ;
this.sliderLabelsTM[t][m].setText$S();
}
}
});

Clazz.newMeth(C$, 'setValues$org_byu_isodistort_local_Mode',  function (otherMode) {
var n=(this.type >= 5 ? 1 : this.numTypes);
for (var t=0; t < n; t++) for (var m=0; m < otherMode.modesPerType[t]; m++) this.sliderTM[t][m].setValue$I(otherMode.sliderTM[t][m].getValue$());


});

Clazz.newMeth(C$, 'setColors$IA$I',  function (atomTypeUnique, numUniques) {
var brightness;
switch (this.type) {
default:
case 0:
brightness=0.95;
break;
case 1:
brightness=0.8;
break;
case 2:
brightness=0.65;
break;
case 3:
brightness=0.55;
break;
case 4:
brightness=0.4;
break;
case 5:
this.colorT[0]=$I$(2).DARK_GRAY;
return;
case 6:
this.colorT[0]=$I$(2).LIGHT_GRAY;
return;
}
if (this.colorT == null ) {
this.colorT=Clazz.array($I$(2), [this.numTypes]);
}var simpleColor=(atomTypeUnique != null );
for (var t=0; t < this.numTypes; t++) {
var k=(simpleColor ? 1.0 * atomTypeUnique[t] / numUniques : 1.0 * t / this.numTypes);
this.colorT[t]=Clazz.new_([$I$(2).HSBtoRGB$F$F$F(k, 1, brightness)],$I$(2,1).c$$I);
}
});

Clazz.newMeth(C$, 'toString',  function () {
return "[Mode " + this.type + " count=" + this.count + "]" ;
});

Clazz.newMeth(C$, 'getVoigtStrainTensor$D$org_byu_isodistort_local_Mode',  function (superSliderVal, irreps) {
var v=Clazz.array(Double.TYPE, [6]);
for (var n=0; n < 6; n++) {
for (var m=0; m < this.count; m++) {
v[n]+=this.vector[m][n] * irreps.sliderValsTM[0][this.irrepTM[0][m]] * this.sliderValsTM[0][m] * superSliderVal ;
}
}
var pStrainPlusIdentity=Clazz.array(Double.TYPE, [3, 3]);
pStrainPlusIdentity[0][0]=v[0] + 1;
pStrainPlusIdentity[1][0]=v[5] / 2;
pStrainPlusIdentity[2][0]=v[4] / 2;
pStrainPlusIdentity[0][1]=v[5] / 2;
pStrainPlusIdentity[1][1]=v[1] + 1;
pStrainPlusIdentity[2][1]=v[3] / 2;
pStrainPlusIdentity[0][2]=v[4] / 2;
pStrainPlusIdentity[1][2]=v[3] / 2;
pStrainPlusIdentity[2][2]=v[2] + 1;
return pStrainPlusIdentity;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2023-12-19 08:02:15 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
