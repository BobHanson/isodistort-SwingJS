(function(){var P$=Clazz.newPackage("com.sun.imageio.plugins.bmp"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "BMPConstants");
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-09-26 09:44:44 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
