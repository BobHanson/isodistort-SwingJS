(function(){var P$=Clazz.newPackage("java.awt.peer"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "PanelPeer", null, null, 'java.awt.peer.LightweightPeer');

C$.$clinit$=2;
})();
;Clazz.setTVer('5.0.1-v1');//Created 2023-11-16 11:21:07 Java2ScriptVisitor version 5.0.1-v1 net.sf.j2s.core.jar version 5.0.1-v1
